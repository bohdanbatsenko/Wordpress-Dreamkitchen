## Juxtapose example in a React component

A CodeSandbox of this example is available here: https://c48ew.csb.app/
